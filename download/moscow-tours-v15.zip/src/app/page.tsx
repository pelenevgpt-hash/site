'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import { 
  MapPin, Clock, Users, Star, Phone, Mail, Instagram, 
  Menu, X, ChevronRight, Building2, TreePine, 
  Camera, Heart, Award, Compass, Send, Globe,
  Church, Landmark, Palette, Rocket, Castle
} from 'lucide-react'

// Данные экскурсий
const tours = [
  {
    id: 1,
    title: 'ВДНХ – музей под открытым небом',
    shortDescription: 'От сталинского ампира до мечты о космосе. Архитектурная капсула времени с павильонами разных эпох.',
    fullDescription: 'ВДНХ — уникальный архитектурный комплекс, где каждый павильон рассказывает свою историю. Вы увидите шедевры сталинского ампира, советского модернизма и постсоветской архитектуры. Все оригинальные постройки недавно отреставрированы. Павильон «Космос» с множеством подлинных экспонатов, легендарные фонтаны «Дружба народов» и «Каменный цветок», монумент «Рабочий и колхозница». Для детских групп провожу увлекательный квест!',
    duration: '3 часа',
    price: 'по запросу',
    groupSize: '1-15 человек',
    difficulty: 'Легкая',
    highlights: ['Павильон «Космос» с подлинными экспонатами', 'Фонтан «Дружба народов»', 'Монумент «Рабочий и колхозница»', 'Архитектура сталинского ампира', 'Детский квест (по запросу)'],
    image: '/tours/vdnh.jpg',
    icon: Landmark,
    color: 'from-amber-600 to-orange-700'
  },
  {
    id: 2,
    title: 'Музей космонавтики',
    shortDescription: 'Почти 100 000 экспонатов — от «Спутника-1» до МКС. Космические мечты, ставшие реальностью.',
    fullDescription: 'Погружение в историю покорения космоса! Вы увидите полноразмерный базовый блок орбитальной станции «Мир», подлинные космические корабли, включая спускаемую капсулу Белки и Стрелки, скафандры Гагарина и Леонова, луноход и образцы метеоритов. Своими глазами увидите, как советские мечты о космосе стали реальностью!',
    duration: '2.5 часа',
    price: 'по запросу',
    groupSize: '1-10 человек',
    difficulty: 'Легкая',
    highlights: ['Орбитальная станция «Мир»', 'Спускаемая капсула Белки и Стрелки', 'Скафандры Гагарина и Леонова', 'Луноход и метеориты', 'Интерактивные экспонаты'],
    image: '/tours/cosmos.jpg',
    icon: Rocket,
    color: 'from-slate-700 to-slate-900'
  },
  {
    id: 3,
    title: 'Новая Третьяковка: XX век',
    shortDescription: 'Русский авангард, соцреализм и андеграунд — крупнейшее собрание искусства XX века.',
    fullDescription: 'Новая Третьяковка на Крымском Валу хранит крупнейшее в России собрание искусства XX века. В коллекции: русский авангард — революционные работы Малевича, Кандинского, Шагала; советское искусство — от монументального соцреализма до «сурового стиля» 1960-х; андеграунд — смелые нонконформистские работы 1960–80-х. Детская экскурсия проводится в интерактивной форме с элементами викторины!',
    duration: '2.5 часа',
    price: 'по запросу',
    groupSize: '1-10 человек',
    difficulty: 'Легкая',
    highlights: ['Работы Малевича и Кандинского', 'Шедевры Шагала', 'Советский соцреализм', 'Андеграунд 60-80х', 'Интерактивная викторина для детей'],
    image: '/tours/tretyakov.jpg',
    icon: Palette,
    color: 'from-rose-700 to-red-800'
  },
  {
    id: 4,
    title: 'Царицыно: резиденция Екатерины',
    shortDescription: 'Летняя резиденция Екатерины Великой с вековой историей и свето-музыкальным фонтаном.',
    fullDescription: 'Комплекс строился для Екатерины Великой в 1776–1796 годах по проекту архитектора Василия Баженова, а позже перестраивался Матвеем Казаковым. Императрица так никогда в нём и не жила. В советскую эпоху руины дворца стали популярным местом для пикников. Полностью восстановлен в 2007 году. Большой дворец сегодня служит выставочным пространством, а свето-музыкальный фонтан восхищает танцующими струями под классическую музыку.',
    duration: '3 часа',
    price: 'по запросу',
    groupSize: '1-15 человек',
    difficulty: 'Легкая',
    highlights: ['Большой дворец', 'Хлебный дом', 'Оперный дом', 'Свето-музыкальный фонтан', 'Парковые прогулки'],
    image: '/tours/tsaritsyno.jpg',
    icon: Castle,
    color: 'from-emerald-700 to-teal-800'
  },
  {
    id: 5,
    title: 'Новодевичий монастырь',
    shortDescription: '500 лет истории: женские судьбы в камне. Объект ЮНЕСКО с впечатляющими башнями и куполами.',
    fullDescription: 'Новодевичьему — 500 лет! Его история началась в 1524 году. Он был и крепостью, и тюрьмой. Сегодня это действующий монастырь и музей, объект ЮНЕСКО с впечатляющими башнями и сияющими куполами. Именно сюда Пётр I отправил свою мятежную сестру, царевну Софью. В 1812 году монастырь чудом уцелел, когда Наполеон приказал его взорвать. Место, где судьбы страны переплетены с личными драмами.',
    duration: '2.5 часа',
    price: 'по запросу',
    groupSize: '1-12 человек',
    difficulty: 'Легкая',
    highlights: ['Действующий монастырь', 'Башни и купола', 'История царевны Софьи', 'Уцелел от Наполеона', 'Объект ЮНЕСКО'],
    image: '/tours/novodevichy.jpg',
    icon: Church,
    color: 'from-amber-700 to-orange-800'
  },
  {
    id: 6,
    title: 'Пешие экскурсии по Москве',
    shortDescription: 'Более 20 маршрутов по исторической Москве: от Красной площади до Замоскворечья.',
    fullDescription: 'В арсенале более 20 пеших маршрутов по исторической Москве! Красная площадь и Александровский сад, Тверская — главная артерия столицы, Старый Арбат в судьбах людей, Китай-город, «Москва уютная» с посещением Марфо-Мариинской обители, Московский Сен-Жермен на Пречистенке, Бульварное кольцо от Гоголя до Высоцкого. Никаких скучных фактов — только живое общение и интерактив! Ни один ребёнок не уходит без памятного сувенира.',
    duration: '2-3 часа',
    price: 'по запросу',
    groupSize: '1-15 человек',
    difficulty: 'Легкая',
    highlights: ['Красная площадь', 'Старый Арбат', 'Китай-город', 'Замоскворечье', 'Бульварное кольцо'],
    image: '/tours/walking.jpg',
    icon: MapPin,
    color: 'from-amber-500 to-yellow-700'
  }
]

// Данные отзывов
const reviews = [
  {
    id: 1,
    name: 'Анна Петрова',
    avatar: '',
    rating: 5,
    tour: 'ВДНХ – музей под открытым небом',
    date: 'март 2024',
    text: 'Иветта — невероятный гид! Столько знала о каждом павильоне, о каждой детали. Дети были в восторге от квеста. Обязательно пойдём ещё!'
  },
  {
    id: 2,
    name: 'Михаил Сидоров',
    avatar: '',
    rating: 5,
    tour: 'Музей космонавтики',
    date: 'февраль 2024',
    text: 'Потрясающая экскурсия! Как будто сам побывал в космосе. Иветта умеет рассказать так, что забываешь о времени. Рекомендую всем!'
  },
  {
    id: 3,
    name: 'Елена Козлова',
    avatar: '',
    rating: 5,
    tour: 'Царицыно',
    date: 'февраль 2024',
    text: 'Волшебное место и волшебный гид! История оживает в рассказах Иветты. Фонтан под музыку — отдельный восторг!'
  },
  {
    id: 4,
    name: 'Дмитрий Волков',
    avatar: '',
    rating: 5,
    tour: 'Пешие экскурсии',
    date: 'январь 2024',
    text: 'Гуляли по Арбату — было невероятно интересно! Узнали столько нового о, казалось бы, знакомых местах. Иветта — настоящий профессионал!'
  },
  {
    id: 5,
    name: 'Ольга Николаева',
    avatar: '',
    rating: 5,
    tour: 'Новая Третьяковка',
    date: 'январь 2024',
    text: 'Для ребёнка экскурсия прошла на ура — викторина, интерактив, всё очень живо и интересно. Спасибо за чудесный день!'
  },
  {
    id: 6,
    name: 'Сергей Иванов',
    avatar: '',
    rating: 5,
    tour: 'Новодевичий монастырь',
    date: 'декабрь 2023',
    text: 'Глубокое погружение в историю! Судьбы женщин, судьба страны — всё переплелось в одном месте. Очень рекомендую!'
  }
]

// Навигация
const navItems = [
  { label: 'Главная', href: '#hero' },
  { label: 'Обо мне', href: '#about' },
  { label: 'Экскурсии', href: '#tours' },
  { label: 'Отзывы', href: '#reviews' },
  { label: 'Контакты', href: '#contact' }
]

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [selectedTour, setSelectedTour] = useState<typeof tours[0] | null>(null)
  const [selectedTourId, setSelectedTourId] = useState<number | null>(null)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  const handleTourSelect = (tourId: number) => {
    setSelectedTourId(tourId)
    setSelectedTour(null)
    scrollToSection('#contact')
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass shadow-lg' : 'bg-transparent'
      }`}>
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <a href="#hero" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl overflow-hidden shadow-lg group-hover:scale-105 transition-transform">
                <img 
                  src="/logo-new.jpeg" 
                  alt="Logo"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-lg text-foreground leading-tight">Москва с Иветтой</span>
              </div>
            </a>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <button
                  key={item.href}
                  onClick={() => scrollToSection(item.href)}
                  className="px-4 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-all font-medium"
                >
                  {item.label}
                </button>
              ))}
              <Link 
                href="/en-tours"
                className="px-4 py-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent/50 transition-all font-medium flex items-center gap-2"
              >
                <Globe className="w-4 h-4" />
                Экскурсии на других языках
              </Link>
            </nav>

            {/* CTA Button */}
            <div className="hidden md:block">
              <Button 
                onClick={() => scrollToSection('#contact')}
                className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all"
              >
                Забронировать
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg hover:bg-accent transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden glass border-t animate-fade-in-up">
            <nav className="container mx-auto px-4 py-4 flex flex-col gap-2">
              {navItems.map((item) => (
                <button
                  key={item.href}
                  onClick={() => scrollToSection(item.href)}
                  className="px-4 py-3 rounded-lg text-left hover:bg-accent/50 transition-colors font-medium"
                >
                  {item.label}
                </button>
              ))}
              <Link 
                href="/en-tours"
                className="px-4 py-3 rounded-lg text-left hover:bg-accent/50 transition-colors font-medium flex items-center gap-2"
              >
                <Globe className="w-4 h-4" />
                Экскурсии на других языках
              </Link>
              <Button 
                onClick={() => scrollToSection('#contact')}
                className="mt-2 bg-primary hover:bg-primary/90 text-primary-foreground"
              >
                Забронировать
              </Button>
            </nav>
          </div>
        )}
      </header>

      {/* Hero Section */}
      <section id="hero" className="relative min-h-screen flex items-center pt-20 gradient-hero overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary/15 rounded-full blur-3xl" />
          <div className="absolute top-1/2 -left-20 w-60 h-60 bg-accent/25 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-1/4 w-40 h-40 bg-amber-500/15 rounded-full blur-2xl" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div className="animate-fade-in-up">
              <Badge variant="secondary" className="mb-6 px-4 py-2 text-sm font-medium border-primary/20">
                <Globe className="w-4 h-4 mr-2 text-primary" />
                Экскурсии на русском, английском и итальянском
              </Badge>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-amber-600 to-accent">
                  Исследуй столицу с опытным гидом
                </span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8 leading-relaxed">
                Аккредитованный гид-переводчик и экскурсовод. Более 20 пеших маршрутов по исторической Москве, более 20 музеев. Автобусные туры и индивидуальное сопровождение. Для детей и взрослых, для частных лиц и групп.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button 
                  size="lg" 
                  onClick={() => scrollToSection('#tours')}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg hover:shadow-xl transition-all text-lg px-8"
                >
                  Смотреть экскурсии
                  <ChevronRight className="w-5 h-5 ml-2" />
                </Button>
                <Button 
                  size="lg" 
                  variant="outline"
                  onClick={() => scrollToSection('#about')}
                  className="border-2 hover:bg-accent/50 transition-all text-lg"
                >
                  Узнать больше
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-8 mt-12 pt-8 border-t">
                <div>
                  <div className="text-3xl font-bold text-primary">50+</div>
                  <div className="text-sm text-muted-foreground">программ</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">3</div>
                  <div className="text-sm text-muted-foreground">языка экскурсий</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">100%</div>
                  <div className="text-sm text-muted-foreground">живых эмоций</div>
                </div>
              </div>
            </div>

            {/* Hero Image/Illustration */}
            <div className="hidden lg:flex items-center justify-center">
              <div className="relative">
                {/* Main card */}
                <div className="w-80 h-96 rounded-3xl shadow-2xl flex items-center justify-center overflow-hidden relative">
                  <img 
                    src="/hero-card.png" 
                    alt="Москва с Иветтой"
                    className="absolute inset-0 w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                  <div className="relative z-10 text-center p-8">
                    <Compass className="w-24 h-24 text-white/90 mx-auto mb-4 animate-float" />
                    <h3 className="text-white text-2xl font-bold mb-2">Москва ждёт</h3>
                    <p className="text-white/80">Выберите свой маршрут</p>
                  </div>
                </div>
                {/* Floating cards */}
                <div className="absolute -top-4 -right-8 glass rounded-xl p-4 shadow-lg animate-float" style={{ animationDelay: '0.5s' }}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center">
                      <Landmark className="w-5 h-5 text-amber-600" />
                    </div>
                    <div className="font-semibold text-sm leading-tight">Музеи</div>
                  </div>
                </div>
                <div className="absolute -bottom-4 -left-8 glass rounded-xl p-4 shadow-lg animate-float" style={{ animationDelay: '1s' }}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-emerald-600" />
                    </div>
                    <div className="font-semibold text-sm leading-tight">Пешие и<br/>автобусные туры</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <button onClick={() => scrollToSection('#about')} className="p-2 rounded-full bg-primary/10 hover:bg-primary/20 transition-colors">
            <ChevronRight className="w-6 h-6 rotate-90 text-primary" />
          </button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 md:py-32 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Image */}
            <div className="relative order-2 lg:order-1">
              <div className="aspect-square max-w-md mx-auto relative">
                {/* Main photo */}
                <div className="absolute inset-4 rounded-3xl bg-gradient-to-br from-primary/20 to-primary/5 shadow-xl overflow-hidden">
                  <img 
                    src="/photo.jpg" 
                    alt="Иветта Красногорская"
                    className="w-full h-full object-cover"
                  />
                </div>
                {/* Decorative elements */}
                <div className="absolute top-0 left-0 w-20 h-20 bg-primary/20 rounded-2xl -rotate-6" />
                <div className="absolute bottom-0 right-0 w-24 h-24 bg-accent/30 rounded-2xl rotate-6" />
              </div>
            </div>

            {/* Content */}
            <div className="order-1 lg:order-2">
              <Badge variant="secondary" className="mb-4">Обо мне</Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Привет! Я Иветта, и я человек, бесконечно влюблённый в свой город
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Я — журналист, лингвист, педагог, преподаватель английского и итальянского 
                  языков. Как аккредитованный экскурсовод и гид-переводчик, я провожу экскурсии 
                  на трёх языках (русском, английском и итальянском) для взрослых и детей, 
                  для частных лиц и групп.
                </p>
                <p>
                  Мой многолетний педагогический опыт помогает превратить абсолютно любую, 
                  даже самую серьёзную прогулку по городу в настоящее приключение для детей — 
                  с интерактивными историями, познавательными играми и уроками-открытиями. 
                  Со мной никогда не бывает скучно!
                </p>
                <p>
                  У меня всегда найдётся увлекательная прогулка и для любителей архитектуры 
                  и искусства, и для любителей интересных историй о людях и вещах. 
                  Никаких скучных фактов — только живое общение и интерактив!
                </p>
              </div>

              {/* Features */}
              <div className="grid sm:grid-cols-2 gap-4 mt-8">
                <div className="flex items-start gap-3 p-4 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Award className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Аккредитованный гид</h4>
                    <p className="text-sm text-muted-foreground">Официальная лицензия</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Globe className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold">3 языка</h4>
                    <p className="text-sm text-muted-foreground">Русский, English, Italiano</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Users className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold">Для детей и взрослых</h4>
                    <p className="text-sm text-muted-foreground">Интерактив для всех</p>
                  </div>
                </div>
                <div className="flex items-start gap-3 p-4 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Heart className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-semibold">С любовью к Москве</h4>
                    <p className="text-sm text-muted-foreground">Влюблён в свой город</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Tours Section */}
      <section id="tours" className="py-20 md:py-32">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center max-w-2xl mx-auto mb-16">
            <Badge variant="secondary" className="mb-4">Экскурсии</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Выберите своё путешествие
            </h2>
            <p className="text-muted-foreground text-lg">
              Более 20 маршрутов по исторической Москве. Каждый — с уникальными историями и интерактивом
            </p>
          </div>

          {/* Tours Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tours.map((tour, index) => {
              const IconComponent = tour.icon
              return (
                <Card 
                  key={tour.id}
                  className="group cursor-pointer overflow-hidden hover:shadow-xl transition-all duration-300 border-0 shadow-md"
                  style={{ animationDelay: `${index * 0.1}s` }}
                  onClick={() => setSelectedTour(tour)}
                >
                  {/* Image */}
                  <div className={`h-48 relative overflow-hidden ${tour.image ? '' : `bg-gradient-to-br ${tour.color}`} `}>
                    {tour.image ? (
                      <>
                        <img 
                          src={tour.image} 
                          alt={tour.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        />
                        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                      </>
                    ) : (
                      <>
                        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
                        <div className="absolute inset-0 flex items-center justify-center">
                          <IconComponent className="w-16 h-16 text-white/80 group-hover:scale-110 transition-transform duration-300" />
                        </div>
                      </>
                    )}
                    {/* Badge */}
                    <Badge className="absolute top-4 right-4 bg-white/90 text-foreground hover:bg-white">
                      {tour.duration}
                    </Badge>
                  </div>
                  
                  <CardHeader className="pb-3">
                    <CardTitle className="text-xl group-hover:text-primary transition-colors">
                      {tour.title}
                    </CardTitle>
                    <CardDescription className="line-clamp-2">
                      {tour.shortDescription}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{tour.groupSize}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{tour.duration}</span>
                        </div>
                      </div>
                      <div className="text-lg font-bold text-primary">
                        {tour.price}
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full mt-4 group-hover:bg-primary group-hover:text-primary-foreground transition-colors"
                      variant="outline"
                    >
                      Подробнее
                      <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-20 md:py-32 bg-muted/30">
        <div className="container mx-auto px-4">
          {/* Header */}
          <div className="text-center max-w-2xl mx-auto mb-16">
            <Badge variant="secondary" className="mb-4">Отзывы</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Что говорят мои гости
            </h2>
            <p className="text-muted-foreground text-lg">
              Искренние слова от людей, которые уже доверили мне свои путешествия
            </p>
          </div>

          {/* Reviews Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((review, index) => (
              <Card 
                key={review.id}
                className="hover:shadow-lg transition-shadow"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <CardContent className="pt-6">
                  {/* Header */}
                  <div className="flex items-start gap-4 mb-4">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={review.avatar} />
                      <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                        {review.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <h4 className="font-semibold">{review.name}</h4>
                      <p className="text-sm text-muted-foreground">{review.tour}</p>
                    </div>
                  </div>
                  
                  {/* Rating */}
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`w-4 h-4 ${i < review.rating ? 'text-amber-400 fill-amber-400' : 'text-muted'}`} 
                      />
                    ))}
                    <span className="text-sm text-muted-foreground ml-2">{review.date}</span>
                  </div>
                  
                  {/* Text */}
                  <p className="text-muted-foreground leading-relaxed">
                    &ldquo;{review.text}&rdquo;
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 md:py-32">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Content */}
            <div>
              <Badge variant="secondary" className="mb-4">Контакты</Badge>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                Открывайте Москву со мной!
              </h2>
              <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
                Забронируйте экскурсию или задайте любой вопрос. Я всегда на связи и с радостью 
                помогу выбрать идеальный маршрут именно для вас.
              </p>

              {/* Contact Info */}
              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-4 p-4 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Phone className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">WhatsApp</div>
                    <div className="font-semibold">+7 926 213 20 39</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Email</div>
                    <div className="font-semibold">ikrasnogorskaya@yandex.ru</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-xl bg-card shadow-sm hover:shadow-md transition-shadow">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Send className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground">Telegram</div>
                    <div className="font-semibold">@ikrasnogorskaya</div>
                  </div>
                </div>
              </div>

              {/* Social Links */}
              <div className="flex items-center gap-3">
                <span className="text-sm text-muted-foreground">Я в соцсетях:</span>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Instagram className="w-5 h-5" />
                </Button>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Send className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Contact Form */}
            <Card className="shadow-xl">
              <CardHeader>
                <CardTitle>Оставить заявку</CardTitle>
                <CardDescription>
                  Заполните форму, и я свяжусь с вами в ближайшее время
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  {/* Selected tour info */}
                  {selectedTourId && (
                    <div className="p-4 rounded-xl bg-primary/5 border border-primary/20 mb-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-muted-foreground">Выбранная экскурсия:</p>
                          <p className="font-semibold text-primary">
                            {tours.find(t => t.id === selectedTourId)?.title}
                          </p>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedTourId(null)}
                          className="text-muted-foreground hover:text-foreground"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-sm font-medium">Имя</label>
                      <input
                        id="name"
                        type="text"
                        placeholder="Ваше имя"
                        className="w-full px-4 py-2 rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-sm font-medium">Телефон</label>
                      <input
                        id="phone"
                        type="tel"
                        placeholder="+7 (___) ___-__-__"
                        className="w-full px-4 py-2 rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">Email</label>
                    <input
                      id="email"
                      type="email"
                      placeholder="your@email.com"
                      className="w-full px-4 py-2 rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="tour" className="text-sm font-medium">Интересующая экскурсия</label>
                    <select
                      id="tour"
                      value={selectedTourId || ''}
                      onChange={(e) => setSelectedTourId(e.target.value ? Number(e.target.value) : null)}
                      className="w-full px-4 py-2 rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="">Выберите экскурсию</option>
                      {tours.map(tour => (
                        <option key={tour.id} value={tour.id}>{tour.title}</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">Сообщение</label>
                    <textarea
                      id="message"
                      rows={4}
                      placeholder="Расскажите о ваших пожеланиях..."
                      className="w-full px-4 py-2 rounded-lg border bg-background focus:outline-none focus:ring-2 focus:ring-primary resize-none"
                    />
                  </div>
                  <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                    Отправить заявку
                    <Send className="w-4 h-4 ml-2" />
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t py-12 mt-auto">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {/* Brand */}
            <div className="md:col-span-2">
              <a href="#hero" className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 rounded-xl overflow-hidden shadow-lg">
                  <img 
                    src="/logo-new.jpeg" 
                    alt="Logo"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex flex-col">
                  <span className="font-bold text-lg">Москва с Иветтой</span>
                </div>
              </a>
              <p className="text-muted-foreground mb-4 max-w-md">
                Аккредитованный гид-переводчик Иветта Красногорская. Экскурсии на русском, 
                английском и итальянском языках. Более 20 пеших маршрутов по исторической Москве.
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="icon" className="rounded-full">
                  <Instagram className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" className="rounded-full">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4">Навигация</h4>
              <ul className="space-y-2">
                {navItems.map(item => (
                  <li key={item.href}>
                    <button
                      onClick={() => scrollToSection(item.href)}
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {item.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-semibold mb-4">Контакты</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  +7 926 213 20 39
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  ikrasnogorskaya@yandex.ru
                </li>
                <li className="flex items-center gap-2">
                  <Send className="w-4 h-4" />
                  @ikrasnogorskaya
                </li>
              </ul>
            </div>
          </div>

          <Separator className="my-8" />

          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
            <p>&copy; 2024 Москва с Иветтой. Все права защищены.</p>
            <p>Сделано с любовью к Москве</p>
          </div>
        </div>
      </footer>

      {/* Tour Detail Modal */}
      <Dialog open={!!selectedTour} onOpenChange={() => setSelectedTour(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          {selectedTour && (
            <>
              <DialogHeader>
                <div className={`h-48 -mx-6 -mt-6 relative overflow-hidden ${selectedTour.image ? '' : `bg-gradient-to-br ${selectedTour.color}`}`}>
                  {selectedTour.image ? (
                    <>
                      <img 
                        src={selectedTour.image} 
                        alt={selectedTour.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/20" />
                    </>
                  ) : (
                    <>
                      <div className="absolute inset-0 bg-black/20" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <selectedTour.icon className="w-20 h-20 text-white/80" />
                      </div>
                    </>
                  )}
                </div>
                <DialogTitle className="text-2xl mt-4">{selectedTour.title}</DialogTitle>
                <DialogDescription className="text-base">
                  {selectedTour.shortDescription}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6">
                {/* Info Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="text-center p-3 rounded-xl bg-muted">
                    <Clock className="w-5 h-5 mx-auto mb-1 text-primary" />
                    <div className="text-sm text-muted-foreground">Длительность</div>
                    <div className="font-semibold">{selectedTour.duration}</div>
                  </div>
                  <div className="text-center p-3 rounded-xl bg-muted">
                    <Users className="w-5 h-5 mx-auto mb-1 text-primary" />
                    <div className="text-sm text-muted-foreground">Группа</div>
                    <div className="font-semibold">{selectedTour.groupSize}</div>
                  </div>
                  <div className="text-center p-3 rounded-xl bg-muted">
                    <MapPin className="w-5 h-5 mx-auto mb-1 text-primary" />
                    <div className="text-sm text-muted-foreground">Сложность</div>
                    <div className="font-semibold">{selectedTour.difficulty}</div>
                  </div>
                  <div className="text-center p-3 rounded-xl bg-muted">
                    <Star className="w-5 h-5 mx-auto mb-1 text-primary" />
                    <div className="text-sm text-muted-foreground">Стоимость</div>
                    <div className="font-bold text-primary">{selectedTour.price}</div>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <h4 className="font-semibold mb-2">Описание</h4>
                  <p className="text-muted-foreground leading-relaxed">
                    {selectedTour.fullDescription}
                  </p>
                </div>

                {/* Highlights */}
                <div>
                  <h4 className="font-semibold mb-3">Что вас ждёт</h4>
                  <ul className="space-y-2">
                    {selectedTour.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-center gap-3">
                        <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                          <ChevronRight className="w-4 h-4 text-primary" />
                        </div>
                        <span className="text-muted-foreground">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA */}
                <div className="flex flex-col sm:flex-row gap-3 pt-4">
                  <Button 
                    className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={() => handleTourSelect(selectedTour.id)}
                  >
                    Забронировать
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setSelectedTour(null)}
                  >
                    Закрыть
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
